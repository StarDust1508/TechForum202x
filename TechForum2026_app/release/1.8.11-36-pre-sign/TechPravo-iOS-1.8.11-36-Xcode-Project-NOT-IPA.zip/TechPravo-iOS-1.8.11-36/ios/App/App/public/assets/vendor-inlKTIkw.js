const Ir="modulepreload",kr=function(e){return"/"+e},Ft={},Ie=function(t,n,r){let o=Promise.resolve();if(n&&n.length>0){let i=function(c){return Promise.all(c.map(m=>Promise.resolve(m).then(g=>({status:"fulfilled",value:g}),g=>({status:"rejected",reason:g}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),l=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));o=i(n.map(c=>{if(c=kr(c),c in Ft)return;Ft[c]=!0;const m=c.endsWith(".css"),g=m?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${c}"]${g}`))return;const h=document.createElement("link");if(h.rel=m?"stylesheet":Ir,m||(h.as="script"),h.crossOrigin="",h.href=c,l&&h.setAttribute("nonce",l),document.head.appendChild(h),m)return new Promise((S,E)=>{h.addEventListener("load",S),h.addEventListener("error",()=>E(new Error(`Unable to preload CSS for ${c}`)))})}))}function s(i){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=i,window.dispatchEvent(a),!a.defaultPrevented)throw i}return o.then(i=>{for(const a of i||[])a.status==="rejected"&&s(a.reason);return t().catch(s)})};function En(e){var t,n,r="";if(typeof e=="string"||typeof e=="number")r+=e;else if(typeof e=="object")if(Array.isArray(e)){var o=e.length;for(t=0;t<o;t++)e[t]&&(n=En(e[t]))&&(r&&(r+=" "),r+=n)}else for(n in e)e[n]&&(r&&(r+=" "),r+=n);return r}function Za(){for(var e,t,n=0,r="",o=arguments.length;n<o;n++)(e=arguments[n])&&(t=En(e))&&(r&&(r+=" "),r+=t);return r}const Tr=(e,t)=>{const n=new Array(e.length+t.length);for(let r=0;r<e.length;r++)n[r]=e[r];for(let r=0;r<t.length;r++)n[e.length+r]=t[r];return n},Cr=(e,t)=>({classGroupId:e,validator:t}),Sn=(e=new Map,t=null,n)=>({nextPart:e,validators:t,classGroupId:n}),Pe="-",$t=[],Ar="arbitrary..",xr=e=>{const t=Rr(e),{conflictingClassGroups:n,conflictingClassGroupModifiers:r}=e;return{getClassGroupId:i=>{if(i.startsWith("[")&&i.endsWith("]"))return Or(i);const a=i.split(Pe),l=a[0]===""&&a.length>1?1:0;return In(a,l,t)},getConflictingClassGroupIds:(i,a)=>{if(a){const l=r[i],c=n[i];return l?c?Tr(c,l):l:c||$t}return n[i]||$t}}},In=(e,t,n)=>{if(e.length-t===0)return n.classGroupId;const o=e[t],s=n.nextPart.get(o);if(s){const c=In(e,t+1,s);if(c)return c}const i=n.validators;if(i===null)return;const a=t===0?e.join(Pe):e.slice(t).join(Pe),l=i.length;for(let c=0;c<l;c++){const m=i[c];if(m.validator(a))return m.classGroupId}},Or=e=>e.slice(1,-1).indexOf(":")===-1?void 0:(()=>{const t=e.slice(1,-1),n=t.indexOf(":"),r=t.slice(0,n);return r?Ar+r:void 0})(),Rr=e=>{const{theme:t,classGroups:n}=e;return Dr(n,t)},Dr=(e,t)=>{const n=Sn();for(const r in e){const o=e[r];vt(o,n,r,t)}return n},vt=(e,t,n,r)=>{const o=e.length;for(let s=0;s<o;s++){const i=e[s];Nr(i,t,n,r)}},Nr=(e,t,n,r)=>{if(typeof e=="string"){Pr(e,t,n);return}if(typeof e=="function"){Mr(e,t,n,r);return}Lr(e,t,n,r)},Pr=(e,t,n)=>{const r=e===""?t:kn(t,e);r.classGroupId=n},Mr=(e,t,n,r)=>{if(Fr(e)){vt(e(r),t,n,r);return}t.validators===null&&(t.validators=[]),t.validators.push(Cr(n,e))},Lr=(e,t,n,r)=>{const o=Object.entries(e),s=o.length;for(let i=0;i<s;i++){const[a,l]=o[i];vt(l,kn(t,a),n,r)}},kn=(e,t)=>{let n=e;const r=t.split(Pe),o=r.length;for(let s=0;s<o;s++){const i=r[s];let a=n.nextPart.get(i);a||(a=Sn(),n.nextPart.set(i,a)),n=a}return n},Fr=e=>"isThemeGetter"in e&&e.isThemeGetter===!0,$r=e=>{if(e<1)return{get:()=>{},set:()=>{}};let t=0,n=Object.create(null),r=Object.create(null);const o=(s,i)=>{n[s]=i,t++,t>e&&(t=0,r=n,n=Object.create(null))};return{get(s){let i=n[s];if(i!==void 0)return i;if((i=r[s])!==void 0)return o(s,i),i},set(s,i){s in n?n[s]=i:o(s,i)}}},ct="!",Bt=":",Br=[],jt=(e,t,n,r,o)=>({modifiers:e,hasImportantModifier:t,baseClassName:n,maybePostfixModifierPosition:r,isExternal:o}),jr=e=>{const{prefix:t,experimentalParseClassName:n}=e;let r=o=>{const s=[];let i=0,a=0,l=0,c;const m=o.length;for(let I=0;I<m;I++){const v=o[I];if(i===0&&a===0){if(v===Bt){s.push(o.slice(l,I)),l=I+1;continue}if(v==="/"){c=I;continue}}v==="["?i++:v==="]"?i--:v==="("?a++:v===")"&&a--}const g=s.length===0?o:o.slice(l);let h=g,S=!1;g.endsWith(ct)?(h=g.slice(0,-1),S=!0):g.startsWith(ct)&&(h=g.slice(1),S=!0);const E=c&&c>l?c-l:void 0;return jt(s,S,h,E)};if(t){const o=t+Bt,s=r;r=i=>i.startsWith(o)?s(i.slice(o.length)):jt(Br,!1,i,void 0,!0)}if(n){const o=r;r=s=>n({className:s,parseClassName:o})}return r},Ur=e=>{const t=new Map;return e.orderSensitiveModifiers.forEach((n,r)=>{t.set(n,1e6+r)}),n=>{const r=[];let o=[];for(let s=0;s<n.length;s++){const i=n[s],a=i[0]==="[",l=t.has(i);a||l?(o.length>0&&(o.sort(),r.push(...o),o=[]),r.push(i)):o.push(i)}return o.length>0&&(o.sort(),r.push(...o)),r}},Hr=e=>({cache:$r(e.cacheSize),parseClassName:jr(e),sortModifiers:Ur(e),...xr(e)}),zr=/\s+/,Vr=(e,t)=>{const{parseClassName:n,getClassGroupId:r,getConflictingClassGroupIds:o,sortModifiers:s}=t,i=[],a=e.trim().split(zr);let l="";for(let c=a.length-1;c>=0;c-=1){const m=a[c],{isExternal:g,modifiers:h,hasImportantModifier:S,baseClassName:E,maybePostfixModifierPosition:I}=n(m);if(g){l=m+(l.length>0?" "+l:l);continue}let v=!!I,D=r(v?E.substring(0,I):E);if(!D){if(!v){l=m+(l.length>0?" "+l:l);continue}if(D=r(E),!D){l=m+(l.length>0?" "+l:l);continue}v=!1}const de=h.length===0?"":h.length===1?h[0]:s(h).join(":"),$=S?de+ct:de,B=$+D;if(i.indexOf(B)>-1)continue;i.push(B);const j=o(D,v);for(let U=0;U<j.length;++U){const H=j[U];i.push($+H)}l=m+(l.length>0?" "+l:l)}return l},Wr=(...e)=>{let t=0,n,r,o="";for(;t<e.length;)(n=e[t++])&&(r=Tn(n))&&(o&&(o+=" "),o+=r);return o},Tn=e=>{if(typeof e=="string")return e;let t,n="";for(let r=0;r<e.length;r++)e[r]&&(t=Tn(e[r]))&&(n&&(n+=" "),n+=t);return n},Kr=(e,...t)=>{let n,r,o,s;const i=l=>{const c=t.reduce((m,g)=>g(m),e());return n=Hr(c),r=n.cache.get,o=n.cache.set,s=a,a(l)},a=l=>{const c=r(l);if(c)return c;const m=Vr(l,n);return o(l,m),m};return s=i,(...l)=>s(Wr(...l))},Gr=[],k=e=>{const t=n=>n[e]||Gr;return t.isThemeGetter=!0,t},Cn=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,An=/^\((?:(\w[\w-]*):)?(.+)\)$/i,qr=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,Jr=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,Yr=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,Xr=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,Qr=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Zr=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,Y=e=>qr.test(e),b=e=>!!e&&!Number.isNaN(Number(e)),X=e=>!!e&&Number.isInteger(Number(e)),Ye=e=>e.endsWith("%")&&b(e.slice(0,-1)),z=e=>Jr.test(e),xn=()=>!0,eo=e=>Yr.test(e)&&!Xr.test(e),_t=()=>!1,to=e=>Qr.test(e),no=e=>Zr.test(e),ro=e=>!u(e)&&!f(e),oo=e=>Z(e,Dn,_t),u=e=>Cn.test(e),ne=e=>Z(e,Nn,eo),Ut=e=>Z(e,ho,b),so=e=>Z(e,Mn,xn),io=e=>Z(e,Pn,_t),Ht=e=>Z(e,On,_t),ao=e=>Z(e,Rn,no),Re=e=>Z(e,Ln,to),f=e=>An.test(e),ve=e=>le(e,Nn),co=e=>le(e,Pn),zt=e=>le(e,On),lo=e=>le(e,Dn),uo=e=>le(e,Rn),De=e=>le(e,Ln,!0),fo=e=>le(e,Mn,!0),Z=(e,t,n)=>{const r=Cn.exec(e);return r?r[1]?t(r[1]):n(r[2]):!1},le=(e,t,n=!1)=>{const r=An.exec(e);return r?r[1]?t(r[1]):n:!1},On=e=>e==="position"||e==="percentage",Rn=e=>e==="image"||e==="url",Dn=e=>e==="length"||e==="size"||e==="bg-size",Nn=e=>e==="length",ho=e=>e==="number",Pn=e=>e==="family-name",Mn=e=>e==="number"||e==="weight",Ln=e=>e==="shadow",po=()=>{const e=k("color"),t=k("font"),n=k("text"),r=k("font-weight"),o=k("tracking"),s=k("leading"),i=k("breakpoint"),a=k("container"),l=k("spacing"),c=k("radius"),m=k("shadow"),g=k("inset-shadow"),h=k("text-shadow"),S=k("drop-shadow"),E=k("blur"),I=k("perspective"),v=k("aspect"),D=k("ease"),de=k("animate"),$=()=>["auto","avoid","all","avoid-page","page","left","right","column"],B=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],j=()=>[...B(),f,u],U=()=>["auto","hidden","clip","visible","scroll"],H=()=>["auto","contain","none"],d=()=>[f,u,l],y=()=>[Y,"full","auto",...d()],O=()=>[X,"none","subgrid",f,u],N=()=>["auto",{span:["full",X,f,u]},X,f,u],R=()=>[X,"auto",f,u],x=()=>["auto","min","max","fr",f,u],J=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],P=()=>["start","end","center","stretch","center-safe","end-safe"],M=()=>["auto",...d()],te=()=>[Y,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...d()],Ke=()=>[Y,"screen","full","dvw","lvw","svw","min","max","fit",...d()],Ge=()=>[Y,"screen","full","lh","dvh","lvh","svh","min","max","fit",...d()],p=()=>[e,f,u],Dt=()=>[...B(),zt,Ht,{position:[f,u]}],Nt=()=>["no-repeat",{repeat:["","x","y","space","round"]}],Pt=()=>["auto","cover","contain",lo,oo,{size:[f,u]}],qe=()=>[Ye,ve,ne],C=()=>["","none","full",c,f,u],A=()=>["",b,ve,ne],Ce=()=>["solid","dashed","dotted","double"],Mt=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],T=()=>[b,Ye,zt,Ht],Lt=()=>["","none",E,f,u],Ae=()=>["none",b,f,u],xe=()=>["none",b,f,u],Je=()=>[b,f,u],Oe=()=>[Y,"full",...d()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[z],breakpoint:[z],color:[xn],container:[z],"drop-shadow":[z],ease:["in","out","in-out"],font:[ro],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[z],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[z],shadow:[z],spacing:["px",b],text:[z],"text-shadow":[z],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",Y,u,f,v]}],container:["container"],columns:[{columns:[b,u,f,a]}],"break-after":[{"break-after":$()}],"break-before":[{"break-before":$()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:j()}],overflow:[{overflow:U()}],"overflow-x":[{"overflow-x":U()}],"overflow-y":[{"overflow-y":U()}],overscroll:[{overscroll:H()}],"overscroll-x":[{"overscroll-x":H()}],"overscroll-y":[{"overscroll-y":H()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:y()}],"inset-x":[{"inset-x":y()}],"inset-y":[{"inset-y":y()}],start:[{"inset-s":y(),start:y()}],end:[{"inset-e":y(),end:y()}],"inset-bs":[{"inset-bs":y()}],"inset-be":[{"inset-be":y()}],top:[{top:y()}],right:[{right:y()}],bottom:[{bottom:y()}],left:[{left:y()}],visibility:["visible","invisible","collapse"],z:[{z:[X,"auto",f,u]}],basis:[{basis:[Y,"full","auto",a,...d()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[b,Y,"auto","initial","none",u]}],grow:[{grow:["",b,f,u]}],shrink:[{shrink:["",b,f,u]}],order:[{order:[X,"first","last","none",f,u]}],"grid-cols":[{"grid-cols":O()}],"col-start-end":[{col:N()}],"col-start":[{"col-start":R()}],"col-end":[{"col-end":R()}],"grid-rows":[{"grid-rows":O()}],"row-start-end":[{row:N()}],"row-start":[{"row-start":R()}],"row-end":[{"row-end":R()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":x()}],"auto-rows":[{"auto-rows":x()}],gap:[{gap:d()}],"gap-x":[{"gap-x":d()}],"gap-y":[{"gap-y":d()}],"justify-content":[{justify:[...J(),"normal"]}],"justify-items":[{"justify-items":[...P(),"normal"]}],"justify-self":[{"justify-self":["auto",...P()]}],"align-content":[{content:["normal",...J()]}],"align-items":[{items:[...P(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...P(),{baseline:["","last"]}]}],"place-content":[{"place-content":J()}],"place-items":[{"place-items":[...P(),"baseline"]}],"place-self":[{"place-self":["auto",...P()]}],p:[{p:d()}],px:[{px:d()}],py:[{py:d()}],ps:[{ps:d()}],pe:[{pe:d()}],pbs:[{pbs:d()}],pbe:[{pbe:d()}],pt:[{pt:d()}],pr:[{pr:d()}],pb:[{pb:d()}],pl:[{pl:d()}],m:[{m:M()}],mx:[{mx:M()}],my:[{my:M()}],ms:[{ms:M()}],me:[{me:M()}],mbs:[{mbs:M()}],mbe:[{mbe:M()}],mt:[{mt:M()}],mr:[{mr:M()}],mb:[{mb:M()}],ml:[{ml:M()}],"space-x":[{"space-x":d()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":d()}],"space-y-reverse":["space-y-reverse"],size:[{size:te()}],"inline-size":[{inline:["auto",...Ke()]}],"min-inline-size":[{"min-inline":["auto",...Ke()]}],"max-inline-size":[{"max-inline":["none",...Ke()]}],"block-size":[{block:["auto",...Ge()]}],"min-block-size":[{"min-block":["auto",...Ge()]}],"max-block-size":[{"max-block":["none",...Ge()]}],w:[{w:[a,"screen",...te()]}],"min-w":[{"min-w":[a,"screen","none",...te()]}],"max-w":[{"max-w":[a,"screen","none","prose",{screen:[i]},...te()]}],h:[{h:["screen","lh",...te()]}],"min-h":[{"min-h":["screen","lh","none",...te()]}],"max-h":[{"max-h":["screen","lh",...te()]}],"font-size":[{text:["base",n,ve,ne]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[r,fo,so]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",Ye,u]}],"font-family":[{font:[co,io,t]}],"font-features":[{"font-features":[u]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[o,f,u]}],"line-clamp":[{"line-clamp":[b,"none",f,Ut]}],leading:[{leading:[s,...d()]}],"list-image":[{"list-image":["none",f,u]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",f,u]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:p()}],"text-color":[{text:p()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...Ce(),"wavy"]}],"text-decoration-thickness":[{decoration:[b,"from-font","auto",f,ne]}],"text-decoration-color":[{decoration:p()}],"underline-offset":[{"underline-offset":[b,"auto",f,u]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:d()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",f,u]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",f,u]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:Dt()}],"bg-repeat":[{bg:Nt()}],"bg-size":[{bg:Pt()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},X,f,u],radial:["",f,u],conic:[X,f,u]},uo,ao]}],"bg-color":[{bg:p()}],"gradient-from-pos":[{from:qe()}],"gradient-via-pos":[{via:qe()}],"gradient-to-pos":[{to:qe()}],"gradient-from":[{from:p()}],"gradient-via":[{via:p()}],"gradient-to":[{to:p()}],rounded:[{rounded:C()}],"rounded-s":[{"rounded-s":C()}],"rounded-e":[{"rounded-e":C()}],"rounded-t":[{"rounded-t":C()}],"rounded-r":[{"rounded-r":C()}],"rounded-b":[{"rounded-b":C()}],"rounded-l":[{"rounded-l":C()}],"rounded-ss":[{"rounded-ss":C()}],"rounded-se":[{"rounded-se":C()}],"rounded-ee":[{"rounded-ee":C()}],"rounded-es":[{"rounded-es":C()}],"rounded-tl":[{"rounded-tl":C()}],"rounded-tr":[{"rounded-tr":C()}],"rounded-br":[{"rounded-br":C()}],"rounded-bl":[{"rounded-bl":C()}],"border-w":[{border:A()}],"border-w-x":[{"border-x":A()}],"border-w-y":[{"border-y":A()}],"border-w-s":[{"border-s":A()}],"border-w-e":[{"border-e":A()}],"border-w-bs":[{"border-bs":A()}],"border-w-be":[{"border-be":A()}],"border-w-t":[{"border-t":A()}],"border-w-r":[{"border-r":A()}],"border-w-b":[{"border-b":A()}],"border-w-l":[{"border-l":A()}],"divide-x":[{"divide-x":A()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":A()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...Ce(),"hidden","none"]}],"divide-style":[{divide:[...Ce(),"hidden","none"]}],"border-color":[{border:p()}],"border-color-x":[{"border-x":p()}],"border-color-y":[{"border-y":p()}],"border-color-s":[{"border-s":p()}],"border-color-e":[{"border-e":p()}],"border-color-bs":[{"border-bs":p()}],"border-color-be":[{"border-be":p()}],"border-color-t":[{"border-t":p()}],"border-color-r":[{"border-r":p()}],"border-color-b":[{"border-b":p()}],"border-color-l":[{"border-l":p()}],"divide-color":[{divide:p()}],"outline-style":[{outline:[...Ce(),"none","hidden"]}],"outline-offset":[{"outline-offset":[b,f,u]}],"outline-w":[{outline:["",b,ve,ne]}],"outline-color":[{outline:p()}],shadow:[{shadow:["","none",m,De,Re]}],"shadow-color":[{shadow:p()}],"inset-shadow":[{"inset-shadow":["none",g,De,Re]}],"inset-shadow-color":[{"inset-shadow":p()}],"ring-w":[{ring:A()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:p()}],"ring-offset-w":[{"ring-offset":[b,ne]}],"ring-offset-color":[{"ring-offset":p()}],"inset-ring-w":[{"inset-ring":A()}],"inset-ring-color":[{"inset-ring":p()}],"text-shadow":[{"text-shadow":["none",h,De,Re]}],"text-shadow-color":[{"text-shadow":p()}],opacity:[{opacity:[b,f,u]}],"mix-blend":[{"mix-blend":[...Mt(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":Mt()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[b]}],"mask-image-linear-from-pos":[{"mask-linear-from":T()}],"mask-image-linear-to-pos":[{"mask-linear-to":T()}],"mask-image-linear-from-color":[{"mask-linear-from":p()}],"mask-image-linear-to-color":[{"mask-linear-to":p()}],"mask-image-t-from-pos":[{"mask-t-from":T()}],"mask-image-t-to-pos":[{"mask-t-to":T()}],"mask-image-t-from-color":[{"mask-t-from":p()}],"mask-image-t-to-color":[{"mask-t-to":p()}],"mask-image-r-from-pos":[{"mask-r-from":T()}],"mask-image-r-to-pos":[{"mask-r-to":T()}],"mask-image-r-from-color":[{"mask-r-from":p()}],"mask-image-r-to-color":[{"mask-r-to":p()}],"mask-image-b-from-pos":[{"mask-b-from":T()}],"mask-image-b-to-pos":[{"mask-b-to":T()}],"mask-image-b-from-color":[{"mask-b-from":p()}],"mask-image-b-to-color":[{"mask-b-to":p()}],"mask-image-l-from-pos":[{"mask-l-from":T()}],"mask-image-l-to-pos":[{"mask-l-to":T()}],"mask-image-l-from-color":[{"mask-l-from":p()}],"mask-image-l-to-color":[{"mask-l-to":p()}],"mask-image-x-from-pos":[{"mask-x-from":T()}],"mask-image-x-to-pos":[{"mask-x-to":T()}],"mask-image-x-from-color":[{"mask-x-from":p()}],"mask-image-x-to-color":[{"mask-x-to":p()}],"mask-image-y-from-pos":[{"mask-y-from":T()}],"mask-image-y-to-pos":[{"mask-y-to":T()}],"mask-image-y-from-color":[{"mask-y-from":p()}],"mask-image-y-to-color":[{"mask-y-to":p()}],"mask-image-radial":[{"mask-radial":[f,u]}],"mask-image-radial-from-pos":[{"mask-radial-from":T()}],"mask-image-radial-to-pos":[{"mask-radial-to":T()}],"mask-image-radial-from-color":[{"mask-radial-from":p()}],"mask-image-radial-to-color":[{"mask-radial-to":p()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":B()}],"mask-image-conic-pos":[{"mask-conic":[b]}],"mask-image-conic-from-pos":[{"mask-conic-from":T()}],"mask-image-conic-to-pos":[{"mask-conic-to":T()}],"mask-image-conic-from-color":[{"mask-conic-from":p()}],"mask-image-conic-to-color":[{"mask-conic-to":p()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:Dt()}],"mask-repeat":[{mask:Nt()}],"mask-size":[{mask:Pt()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",f,u]}],filter:[{filter:["","none",f,u]}],blur:[{blur:Lt()}],brightness:[{brightness:[b,f,u]}],contrast:[{contrast:[b,f,u]}],"drop-shadow":[{"drop-shadow":["","none",S,De,Re]}],"drop-shadow-color":[{"drop-shadow":p()}],grayscale:[{grayscale:["",b,f,u]}],"hue-rotate":[{"hue-rotate":[b,f,u]}],invert:[{invert:["",b,f,u]}],saturate:[{saturate:[b,f,u]}],sepia:[{sepia:["",b,f,u]}],"backdrop-filter":[{"backdrop-filter":["","none",f,u]}],"backdrop-blur":[{"backdrop-blur":Lt()}],"backdrop-brightness":[{"backdrop-brightness":[b,f,u]}],"backdrop-contrast":[{"backdrop-contrast":[b,f,u]}],"backdrop-grayscale":[{"backdrop-grayscale":["",b,f,u]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[b,f,u]}],"backdrop-invert":[{"backdrop-invert":["",b,f,u]}],"backdrop-opacity":[{"backdrop-opacity":[b,f,u]}],"backdrop-saturate":[{"backdrop-saturate":[b,f,u]}],"backdrop-sepia":[{"backdrop-sepia":["",b,f,u]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":d()}],"border-spacing-x":[{"border-spacing-x":d()}],"border-spacing-y":[{"border-spacing-y":d()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",f,u]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[b,"initial",f,u]}],ease:[{ease:["linear","initial",D,f,u]}],delay:[{delay:[b,f,u]}],animate:[{animate:["none",de,f,u]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[I,f,u]}],"perspective-origin":[{"perspective-origin":j()}],rotate:[{rotate:Ae()}],"rotate-x":[{"rotate-x":Ae()}],"rotate-y":[{"rotate-y":Ae()}],"rotate-z":[{"rotate-z":Ae()}],scale:[{scale:xe()}],"scale-x":[{"scale-x":xe()}],"scale-y":[{"scale-y":xe()}],"scale-z":[{"scale-z":xe()}],"scale-3d":["scale-3d"],skew:[{skew:Je()}],"skew-x":[{"skew-x":Je()}],"skew-y":[{"skew-y":Je()}],transform:[{transform:[f,u,"","none","gpu","cpu"]}],"transform-origin":[{origin:j()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:Oe()}],"translate-x":[{"translate-x":Oe()}],"translate-y":[{"translate-y":Oe()}],"translate-z":[{"translate-z":Oe()}],"translate-none":["translate-none"],accent:[{accent:p()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:p()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",f,u]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":d()}],"scroll-mx":[{"scroll-mx":d()}],"scroll-my":[{"scroll-my":d()}],"scroll-ms":[{"scroll-ms":d()}],"scroll-me":[{"scroll-me":d()}],"scroll-mbs":[{"scroll-mbs":d()}],"scroll-mbe":[{"scroll-mbe":d()}],"scroll-mt":[{"scroll-mt":d()}],"scroll-mr":[{"scroll-mr":d()}],"scroll-mb":[{"scroll-mb":d()}],"scroll-ml":[{"scroll-ml":d()}],"scroll-p":[{"scroll-p":d()}],"scroll-px":[{"scroll-px":d()}],"scroll-py":[{"scroll-py":d()}],"scroll-ps":[{"scroll-ps":d()}],"scroll-pe":[{"scroll-pe":d()}],"scroll-pbs":[{"scroll-pbs":d()}],"scroll-pbe":[{"scroll-pbe":d()}],"scroll-pt":[{"scroll-pt":d()}],"scroll-pr":[{"scroll-pr":d()}],"scroll-pb":[{"scroll-pb":d()}],"scroll-pl":[{"scroll-pl":d()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",f,u]}],fill:[{fill:["none",...p()]}],"stroke-w":[{stroke:[b,ve,ne,Ut]}],stroke:[{stroke:["none",...p()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},ec=Kr(po);/*! Capacitor: https://capacitorjs.com/ - MIT License */var he;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(he||(he={}));class Xe extends Error{constructor(t,n,r){super(t),this.message=t,this.code=n,this.data=r}}const go=e=>{var t,n;return e!=null&&e.androidBridge?"android":!((n=(t=e==null?void 0:e.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||n===void 0)&&n.bridge?"ios":"web"},mo=e=>{const t=e.CapacitorCustomPlatform||null,n=e.Capacitor||{},r=n.Plugins=n.Plugins||{},o=()=>t!==null?t.name:go(e),s=()=>o()!=="web",i=g=>{const h=c.get(g);return!!(h!=null&&h.platforms.has(o())||a(g))},a=g=>{var h;return(h=n.PluginHeaders)===null||h===void 0?void 0:h.find(S=>S.name===g)},l=g=>e.console.error(g),c=new Map,m=(g,h={})=>{const S=c.get(g);if(S)return console.warn(`Capacitor plugin "${g}" already registered. Cannot register plugins twice.`),S.proxy;const E=o(),I=a(g);let v;const D=async()=>(!v&&E in h?v=typeof h[E]=="function"?v=await h[E]():v=h[E]:t!==null&&!v&&"web"in h&&(v=typeof h.web=="function"?v=await h.web():v=h.web),v),de=(d,y)=>{var O,N;if(I){const R=I==null?void 0:I.methods.find(x=>y===x.name);if(R)return R.rtype==="promise"?x=>n.nativePromise(g,y.toString(),x):(x,J)=>n.nativeCallback(g,y.toString(),x,J);if(d)return(O=d[y])===null||O===void 0?void 0:O.bind(d)}else{if(d)return(N=d[y])===null||N===void 0?void 0:N.bind(d);throw new Xe(`"${g}" plugin is not implemented on ${E}`,he.Unimplemented)}},$=d=>{let y;const O=(...N)=>{const R=D().then(x=>{const J=de(x,d);if(J){const P=J(...N);return y=P==null?void 0:P.remove,P}else throw new Xe(`"${g}.${d}()" is not implemented on ${E}`,he.Unimplemented)});return d==="addListener"&&(R.remove=async()=>y()),R};return O.toString=()=>`${d.toString()}() { [capacitor code] }`,Object.defineProperty(O,"name",{value:d,writable:!1,configurable:!1}),O},B=$("addListener"),j=$("removeListener"),U=(d,y)=>{const O=B({eventName:d},y),N=async()=>{const x=await O;j({eventName:d,callbackId:x},y)},R=new Promise(x=>O.then(()=>x({remove:N})));return R.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await N()},R},H=new Proxy({},{get(d,y){switch(y){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return I?U:B;case"removeListener":return j;default:return $(y)}}});return r[g]=H,c.set(g,{name:g,proxy:H,platforms:new Set([...Object.keys(h),...I?[E]:[]])}),H};return n.convertFileSrc||(n.convertFileSrc=g=>g),n.getPlatform=o,n.handleError=l,n.isNativePlatform=s,n.isPluginAvailable=i,n.registerPlugin=m,n.Exception=Xe,n.DEBUG=!!n.DEBUG,n.isLoggingEnabled=!!n.isLoggingEnabled,n},bo=e=>e.Capacitor=mo(e),lt=bo(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),q=lt.registerPlugin;class ee{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,n){let r=!1;this.listeners[t]||(this.listeners[t]=[],r=!0),this.listeners[t].push(n);const s=this.windowListeners[t];s&&!s.registered&&this.addWindowListener(s),r&&this.sendRetainedArgumentsForEvent(t);const i=async()=>this.removeListener(t,n);return Promise.resolve({remove:i})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,n,r){const o=this.listeners[t];if(!o){if(r){let s=this.retainedEventArguments[t];s||(s=[]),s.push(n),this.retainedEventArguments[t]=s}return}o.forEach(s=>s(n))}hasListeners(t){var n;return!!(!((n=this.listeners[t])===null||n===void 0)&&n.length)}registerWindowListener(t,n){this.windowListeners[n]={registered:!1,windowEventName:t,pluginEventName:n,handler:r=>{this.notifyListeners(n,r)}}}unimplemented(t="not implemented"){return new lt.Exception(t,he.Unimplemented)}unavailable(t="not available"){return new lt.Exception(t,he.Unavailable)}async removeListener(t,n){const r=this.listeners[t];if(!r)return;const o=r.indexOf(n);this.listeners[t].splice(o,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const n=this.retainedEventArguments[t];n&&(delete this.retainedEventArguments[t],n.forEach(r=>{this.notifyListeners(t,r)}))}}const Vt=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Wt=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class wo extends ee{async getCookies(){const t=document.cookie,n={};return t.split(";").forEach(r=>{if(r.length<=0)return;let[o,s]=r.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");o=Wt(o).trim(),s=Wt(s).trim(),n[o]=s}),n}async setCookie(t){try{const n=Vt(t.key),r=Vt(t.value),o=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",s=(t.path||"/").replace("path=",""),i=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${n}=${r||""}${o}; path=${s}; ${i};`}catch(n){return Promise.reject(n)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(n){return Promise.reject(n)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const n of t)document.cookie=n.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}q("CapacitorCookies",{web:()=>new wo});const yo=async e=>new Promise((t,n)=>{const r=new FileReader;r.onload=()=>{const o=r.result;t(o.indexOf(",")>=0?o.split(",")[1]:o)},r.onerror=o=>n(o),r.readAsDataURL(e)}),vo=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(o=>o.toLocaleLowerCase()).reduce((o,s,i)=>(o[s]=e[t[i]],o),{})},_o=(e,t=!0)=>e?Object.entries(e).reduce((r,o)=>{const[s,i]=o;let a,l;return Array.isArray(i)?(l="",i.forEach(c=>{a=t?encodeURIComponent(c):c,l+=`${s}=${a}&`}),l.slice(0,-1)):(a=t?encodeURIComponent(i):i,l=`${s}=${a}`),`${r}&${l}`},"").substr(1):null,Eo=(e,t={})=>{const n=Object.assign({method:e.method||"GET",headers:e.headers},t),o=vo(e.headers)["content-type"]||"";if(typeof e.data=="string")n.body=e.data;else if(o.includes("application/x-www-form-urlencoded")){const s=new URLSearchParams;for(const[i,a]of Object.entries(e.data||{}))s.set(i,a);n.body=s.toString()}else if(o.includes("multipart/form-data")||e.data instanceof FormData){const s=new FormData;if(e.data instanceof FormData)e.data.forEach((a,l)=>{s.append(l,a)});else for(const a of Object.keys(e.data))s.append(a,e.data[a]);n.body=s;const i=new Headers(n.headers);i.delete("content-type"),n.headers=i}else(o.includes("application/json")||typeof e.data=="object")&&(n.body=JSON.stringify(e.data));return n};class So extends ee{async request(t){const n=Eo(t,t.webFetchExtra),r=_o(t.params,t.shouldEncodeUrlParams),o=r?`${t.url}?${r}`:t.url,s=await fetch(o,n),i=s.headers.get("content-type")||"";let{responseType:a="text"}=s.ok?t:{};i.includes("application/json")&&(a="json");let l,c;switch(a){case"arraybuffer":case"blob":c=await s.blob(),l=await yo(c);break;case"json":l=await s.json();break;case"document":case"text":default:l=await s.text()}const m={};return s.headers.forEach((g,h)=>{m[h]=g}),{data:l,headers:m,status:s.status,url:s.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}q("CapacitorHttp",{web:()=>new So});var Kt;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(Kt||(Kt={}));var Gt;(function(e){e.StatusBar="StatusBar",e.NavigationBar="NavigationBar"})(Gt||(Gt={}));class Io extends ee{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}q("SystemBars",{web:()=>new Io});var qt;(function(e){e[e.Min=1]="Min",e[e.Low=2]="Low",e[e.Default=3]="Default",e[e.High=4]="High",e[e.Max=5]="Max"})(qt||(qt={}));var Jt;(function(e){e[e.Secret=-1]="Secret",e[e.Private=0]="Private",e[e.Public=1]="Public"})(Jt||(Jt={}));const tc=q("FirebaseMessaging",{web:()=>Ie(()=>Promise.resolve().then(()=>$a),void 0).then(e=>new e.FirebaseMessagingWeb)});var Qe={exports:{}},Yt;function nc(){return Yt||(Yt=1,(function(e){var t={single_source_shortest_paths:function(n,r,o){var s={},i={};i[r]=0;var a=t.PriorityQueue.make();a.push(r,0);for(var l,c,m,g,h,S,E,I,v;!a.empty();){l=a.pop(),c=l.value,g=l.cost,h=n[c]||{};for(m in h)h.hasOwnProperty(m)&&(S=h[m],E=g+S,I=i[m],v=typeof i[m]>"u",(v||I>E)&&(i[m]=E,a.push(m,E),s[m]=c))}if(typeof o<"u"&&typeof i[o]>"u"){var D=["Could not find a path from ",r," to ",o,"."].join("");throw new Error(D)}return s},extract_shortest_path_from_predecessor_list:function(n,r){for(var o=[],s=r;s;)o.push(s),n[s],s=n[s];return o.reverse(),o},find_path:function(n,r,o){var s=t.single_source_shortest_paths(n,r,o);return t.extract_shortest_path_from_predecessor_list(s,o)},PriorityQueue:{make:function(n){var r=t.PriorityQueue,o={},s;n=n||{};for(s in r)r.hasOwnProperty(s)&&(o[s]=r[s]);return o.queue=[],o.sorter=n.sorter||r.default_sorter,o},default_sorter:function(n,r){return n.cost-r.cost},push:function(n,r){var o={value:n,cost:r};this.queue.push(o),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};e.exports=t})(Qe)),Qe.exports}var Me;(function(e){e[e.NONE=0]="NONE",e[e.TOUCH_ID=1]="TOUCH_ID",e[e.FACE_ID=2]="FACE_ID",e[e.FINGERPRINT=3]="FINGERPRINT",e[e.FACE_AUTHENTICATION=4]="FACE_AUTHENTICATION",e[e.IRIS_AUTHENTICATION=5]="IRIS_AUTHENTICATION",e[e.MULTIPLE=6]="MULTIPLE",e[e.DEVICE_CREDENTIAL=7]="DEVICE_CREDENTIAL"})(Me||(Me={}));var Le;(function(e){e[e.NONE=0]="NONE",e[e.STRONG=1]="STRONG",e[e.WEAK=2]="WEAK"})(Le||(Le={}));var dt;(function(e){e[e.NONE=0]="NONE",e[e.BIOMETRY_CURRENT_SET=1]="BIOMETRY_CURRENT_SET",e[e.BIOMETRY_ANY=2]="BIOMETRY_ANY"})(dt||(dt={}));var ut;(function(e){e[e.UNKNOWN_ERROR=0]="UNKNOWN_ERROR",e[e.BIOMETRICS_UNAVAILABLE=1]="BIOMETRICS_UNAVAILABLE",e[e.USER_LOCKOUT=2]="USER_LOCKOUT",e[e.BIOMETRICS_NOT_ENROLLED=3]="BIOMETRICS_NOT_ENROLLED",e[e.USER_TEMPORARY_LOCKOUT=4]="USER_TEMPORARY_LOCKOUT",e[e.AUTHENTICATION_FAILED=10]="AUTHENTICATION_FAILED",e[e.APP_CANCEL=11]="APP_CANCEL",e[e.INVALID_CONTEXT=12]="INVALID_CONTEXT",e[e.NOT_INTERACTIVE=13]="NOT_INTERACTIVE",e[e.PASSCODE_NOT_SET=14]="PASSCODE_NOT_SET",e[e.SYSTEM_CANCEL=15]="SYSTEM_CANCEL",e[e.USER_CANCEL=16]="USER_CANCEL",e[e.USER_FALLBACK=17]="USER_FALLBACK"})(ut||(ut={}));const ko=q("NativeBiometric",{web:()=>Ie(()=>Promise.resolve().then(()=>Ka),void 0).then(e=>new e.NativeBiometricWeb)}),rc=Object.freeze(Object.defineProperty({__proto__:null,get AccessControl(){return dt},get AuthenticationStrength(){return Le},get BiometricAuthError(){return ut},get BiometryType(){return Me},NativeBiometric:ko},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const To=()=>{};var Xt={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fn=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let o=e.charCodeAt(r);o<128?t[n++]=o:o<2048?(t[n++]=o>>6|192,t[n++]=o&63|128):(o&64512)===55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===56320?(o=65536+((o&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=o>>18|240,t[n++]=o>>12&63|128,t[n++]=o>>6&63|128,t[n++]=o&63|128):(t[n++]=o>>12|224,t[n++]=o>>6&63|128,t[n++]=o&63|128)}return t},Co=function(e){const t=[];let n=0,r=0;for(;n<e.length;){const o=e[n++];if(o<128)t[r++]=String.fromCharCode(o);else if(o>191&&o<224){const s=e[n++];t[r++]=String.fromCharCode((o&31)<<6|s&63)}else if(o>239&&o<365){const s=e[n++],i=e[n++],a=e[n++],l=((o&7)<<18|(s&63)<<12|(i&63)<<6|a&63)-65536;t[r++]=String.fromCharCode(55296+(l>>10)),t[r++]=String.fromCharCode(56320+(l&1023))}else{const s=e[n++],i=e[n++];t[r++]=String.fromCharCode((o&15)<<12|(s&63)<<6|i&63)}}return t.join("")},$n={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let o=0;o<e.length;o+=3){const s=e[o],i=o+1<e.length,a=i?e[o+1]:0,l=o+2<e.length,c=l?e[o+2]:0,m=s>>2,g=(s&3)<<4|a>>4;let h=(a&15)<<2|c>>6,S=c&63;l||(S=64,i||(h=64)),r.push(n[m],n[g],n[h],n[S])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(Fn(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):Co(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let o=0;o<e.length;){const s=n[e.charAt(o++)],a=o<e.length?n[e.charAt(o)]:0;++o;const c=o<e.length?n[e.charAt(o)]:64;++o;const g=o<e.length?n[e.charAt(o)]:64;if(++o,s==null||a==null||c==null||g==null)throw new Ao;const h=s<<2|a>>4;if(r.push(h),c!==64){const S=a<<4&240|c>>2;if(r.push(S),g!==64){const E=c<<6&192|g;r.push(E)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Ao extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const xo=function(e){const t=Fn(e);return $n.encodeByteArray(t,!0)},Bn=function(e){return xo(e).replace(/\./g,"")},Oo=function(e){try{return $n.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ro(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Do=()=>Ro().__FIREBASE_DEFAULTS__,No=()=>{if(typeof process>"u"||typeof Xt>"u")return;const e=Xt.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},Po=()=>{if(typeof document>"u")return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=e&&Oo(e[1]);return t&&JSON.parse(t)},Mo=()=>{try{return To()||Do()||No()||Po()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},jn=()=>{var e;return(e=Mo())==null?void 0:e.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lo{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,n)=>{this.resolve=t,this.reject=n})}wrapCallback(t){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(n):t(n,r))}}}function Un(){try{return typeof indexedDB=="object"}catch{return!1}}function Hn(){return new Promise((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(r);o.onsuccess=()=>{o.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},o.onupgradeneeded=()=>{n=!1},o.onerror=()=>{var s;t(((s=o.error)==null?void 0:s.message)||"")}}catch(n){t(n)}})}function Fo(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $o="FirebaseError";class me extends Error{constructor(t,n,r){super(n),this.code=t,this.customData=r,this.name=$o,Object.setPrototypeOf(this,me.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ue.prototype.create)}}class Ue{constructor(t,n,r){this.service=t,this.serviceName=n,this.errors=r}create(t,...n){const r=n[0]||{},o=`${this.service}/${t}`,s=this.errors[t],i=s?Bo(s,r):"Error",a=`${this.serviceName}: ${i} (${o}).`;return new me(o,a,r)}}function Bo(e,t){try{let n=0,r="";for(;n<e.length;){const o=e.indexOf("{$",n);if(o===-1){r+=e.substring(n);break}const s=e.indexOf("}",o+2);if(s===-1){r+=e.substring(n);break}const i=e.substring(o+2,s),a=t[i];r+=e.substring(n,o)+(a!=null?String(a):`<${i}?>`),n=s+1}return r}catch{return e}}function ft(e,t){if(e===t)return!0;const n=Object.keys(e),r=Object.keys(t);for(const o of n){if(!r.includes(o))return!1;const s=e[o],i=t[o];if(Qt(s)&&Qt(i)){if(!ft(s,i))return!1}else if(s!==i)return!1}for(const o of r)if(!n.includes(o))return!1;return!0}function Qt(e){return e!==null&&typeof e=="object"}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function He(e){return e&&e._delegate?e._delegate:e}class Q{constructor(t,n,r){this.name=t,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const re="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jo{constructor(t,n){this.name=t,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const n=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(n)){const r=new Lo;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:n});o&&r.resolve(o)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(t){const n=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),r=(t==null?void 0:t.optional)??!1;if(this.isInitialized(n)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:n})}catch(o){if(r)return null;throw o}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(Ho(t))try{this.getOrInitializeService({instanceIdentifier:re})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(n);try{const s=this.getOrInitializeService({instanceIdentifier:o});r.resolve(s)}catch{}}}}clearInstance(t=re){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...t.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=re){return this.instances.has(t)}getOptions(t=re){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:n={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[s,i]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(s);r===a&&i.resolve(o)}return o}onInit(t,n){const r=this.normalizeInstanceIdentifier(n),o=this.onInitCallbacks.get(r)??new Set;o.add(t),this.onInitCallbacks.set(r,o);const s=this.instances.get(r);return s&&t(s,r),()=>{o.delete(t)}}invokeOnInitCallbacks(t,n){const r=this.onInitCallbacks.get(n);if(r)for(const o of r)try{o(t,n)}catch{}}getOrInitializeService({instanceIdentifier:t,options:n={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Uo(t),options:n}),this.instances.set(t,r),this.instancesOptions.set(t,n),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=re){return this.component?this.component.multipleInstances?t:re:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Uo(e){return e===re?void 0:e}function Ho(e){return e.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zo{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const n=this.getProvider(t.name);if(n.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);n.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const n=new jo(t,this);return this.providers.set(t,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var _;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(_||(_={}));const Vo={debug:_.DEBUG,verbose:_.VERBOSE,info:_.INFO,warn:_.WARN,error:_.ERROR,silent:_.SILENT},Wo=_.INFO,Ko={[_.DEBUG]:"log",[_.VERBOSE]:"log",[_.INFO]:"info",[_.WARN]:"warn",[_.ERROR]:"error"},Go=(e,t,...n)=>{if(t<e.logLevel)return;const r=new Date().toISOString(),o=Ko[t];if(o)console[o](`[${r}]  ${e.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class qo{constructor(t){this.name=t,this._logLevel=Wo,this._logHandler=Go,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in _))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?Vo[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,_.DEBUG,...t),this._logHandler(this,_.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,_.VERBOSE,...t),this._logHandler(this,_.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,_.INFO,...t),this._logHandler(this,_.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,_.WARN,...t),this._logHandler(this,_.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,_.ERROR,...t),this._logHandler(this,_.ERROR,...t)}}const Jo=(e,t)=>t.some(n=>e instanceof n);let Zt,en;function Yo(){return Zt||(Zt=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Xo(){return en||(en=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const zn=new WeakMap,ht=new WeakMap,Vn=new WeakMap,Ze=new WeakMap,Et=new WeakMap;function Qo(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",s),e.removeEventListener("error",i)},s=()=>{n(W(e.result)),o()},i=()=>{r(e.error),o()};e.addEventListener("success",s),e.addEventListener("error",i)});return t.then(n=>{n instanceof IDBCursor&&zn.set(n,e)}).catch(()=>{}),Et.set(t,e),t}function Zo(e){if(ht.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",s),e.removeEventListener("error",i),e.removeEventListener("abort",i)},s=()=>{n(),o()},i=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",s),e.addEventListener("error",i),e.addEventListener("abort",i)});ht.set(e,t)}let pt={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return ht.get(e);if(t==="objectStoreNames")return e.objectStoreNames||Vn.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return W(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function es(e){pt=e(pt)}function ts(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(et(this),t,...n);return Vn.set(r,t.sort?t.sort():[t]),W(r)}:Xo().includes(e)?function(...t){return e.apply(et(this),t),W(zn.get(this))}:function(...t){return W(e.apply(et(this),t))}}function ns(e){return typeof e=="function"?ts(e):(e instanceof IDBTransaction&&Zo(e),Jo(e,Yo())?new Proxy(e,pt):e)}function W(e){if(e instanceof IDBRequest)return Qo(e);if(Ze.has(e))return Ze.get(e);const t=ns(e);return t!==e&&(Ze.set(e,t),Et.set(t,e)),t}const et=e=>Et.get(e);function ze(e,t,{blocked:n,upgrade:r,blocking:o,terminated:s}={}){const i=indexedDB.open(e,t),a=W(i);return r&&i.addEventListener("upgradeneeded",l=>{r(W(i.result),l.oldVersion,l.newVersion,W(i.transaction),l)}),n&&i.addEventListener("blocked",l=>n(l.oldVersion,l.newVersion,l)),a.then(l=>{s&&l.addEventListener("close",()=>s()),o&&l.addEventListener("versionchange",c=>o(c.oldVersion,c.newVersion,c))}).catch(()=>{}),a}function Ne(e,{blocked:t}={}){const n=indexedDB.deleteDatabase(e);return t&&n.addEventListener("blocked",r=>t(r.oldVersion,r)),W(n).then(()=>{})}const rs=["get","getKey","getAll","getAllKeys","count"],os=["put","add","delete","clear"],tt=new Map;function tn(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(tt.get(t))return tt.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=os.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||rs.includes(n)))return;const s=async function(i,...a){const l=this.transaction(i,o?"readwrite":"readonly");let c=l.store;return r&&(c=c.index(a.shift())),(await Promise.all([c[n](...a),o&&l.done]))[0]};return tt.set(t,s),s}es(e=>({...e,get:(t,n,r)=>tn(t,n)||e.get(t,n,r),has:(t,n)=>!!tn(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ss{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(is(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function is(e){const t=e.getComponent();return(t==null?void 0:t.type)==="VERSION"}const gt="@firebase/app",nn="0.16.1";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K=new qo("@firebase/app"),as="@firebase/app-compat",cs="@firebase/analytics-compat",ls="@firebase/analytics",ds="@firebase/app-check-compat",us="@firebase/app-check",fs="@firebase/auth",hs="@firebase/auth-compat",ps="@firebase/database",gs="@firebase/data-connect",ms="@firebase/database-compat",bs="@firebase/functions",ws="@firebase/functions-compat",ys="@firebase/installations",vs="@firebase/installations-compat",_s="@firebase/messaging",Es="@firebase/messaging-compat",Ss="@firebase/performance",Is="@firebase/performance-compat",ks="@firebase/remote-config",Ts="@firebase/remote-config-compat",Cs="@firebase/storage",As="@firebase/storage-compat",xs="@firebase/firestore",Os="@firebase/ai",Rs="@firebase/firestore-compat",Ds="firebase";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mt="[DEFAULT]",Ns={[gt]:"fire-core",[as]:"fire-core-compat",[ls]:"fire-analytics",[cs]:"fire-analytics-compat",[us]:"fire-app-check",[ds]:"fire-app-check-compat",[fs]:"fire-auth",[hs]:"fire-auth-compat",[ps]:"fire-rtdb",[gs]:"fire-data-connect",[ms]:"fire-rtdb-compat",[bs]:"fire-fn",[ws]:"fire-fn-compat",[ys]:"fire-iid",[vs]:"fire-iid-compat",[_s]:"fire-fcm",[Es]:"fire-fcm-compat",[Ss]:"fire-perf",[Is]:"fire-perf-compat",[ks]:"fire-rc",[Ts]:"fire-rc-compat",[Cs]:"fire-gcs",[As]:"fire-gcs-compat",[xs]:"fire-fst",[Rs]:"fire-fst-compat",[Os]:"fire-vertex","fire-js":"fire-js",[Ds]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fe=new Map,Ps=new Map,bt=new Map;function rn(e,t){try{e.container.addComponent(t)}catch(n){K.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function ie(e){const t=e.name;if(bt.has(t))return K.debug(`There were multiple attempts to register component ${t}.`),!1;bt.set(t,e);for(const n of Fe.values())rn(n,e);for(const n of Ps.values())rn(n,e);return!0}function St(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ms={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},V=new Ue("app","Firebase",Ms);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ls{constructor(t,n,r){this._isDeleted=!1,this._options={...t},this._config={...n},this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new Q("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw V.create("app-deleted",{appName:this._name})}}function Fs(e,t={}){let n=e;typeof t!="object"&&(t={name:t});const r={name:mt,automaticDataCollectionEnabled:!0,...t},o=r.name;if(typeof o!="string"||!o)throw V.create("bad-app-name",{appName:String(o)});if(n||(n=jn()),!n)throw V.create("no-options");const s=Fe.get(o);if(s)if(ft(n,s.options)){if(ft(r,s.config))return s;throw V.create("duplicate-app",{appName:o,mismatchedParam:"config",oldValue:JSON.stringify(s.config),newValue:JSON.stringify(r)})}else throw V.create("duplicate-app",{appName:o,mismatchedParam:"options",oldValue:JSON.stringify(s.options),newValue:JSON.stringify(n)});const i=new zo(o);for(const l of bt.values())i.addComponent(l);const a=new Ls(n,r,i);return Fe.set(o,a),a}function $s(e=mt){const t=Fe.get(e);if(!t&&e===mt&&jn())return Fs();if(!t)throw V.create("no-app",{appName:e});return t}function se(e,t,n){let r=Ns[e]??e;n&&(r+=`-${n}`);const o=r.match(/\s|\//),s=t.match(/\s|\//);if(o||s){const i=[`Unable to register library "${r}" with version "${t}":`];o&&i.push(`library name "${r}" contains illegal characters (whitespace or "/")`),o&&s&&i.push("and"),s&&i.push(`version name "${t}" contains illegal characters (whitespace or "/")`),K.warn(i.join(" "));return}ie(new Q(`${r}-version`,()=>({library:r,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bs="firebase-heartbeat-database",js=1,Se="firebase-heartbeat-store";let nt=null;function Wn(){return nt||(nt=ze(Bs,js,{upgrade:(e,t)=>{switch(t){case 0:try{e.createObjectStore(Se)}catch(n){console.warn(n)}}}}).catch(e=>{throw V.create("idb-open",{originalErrorMessage:e.message})})),nt}async function Us(e){try{const n=(await Wn()).transaction(Se),r=await n.objectStore(Se).get(Kn(e));return await n.done,r}catch(t){if(t instanceof me)K.warn(t.message);else{const n=V.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});K.warn(n.message)}}}async function on(e,t){try{const r=(await Wn()).transaction(Se,"readwrite");await r.objectStore(Se).put(t,Kn(e)),await r.done}catch(n){if(n instanceof me)K.warn(n.message);else{const r=V.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});K.warn(r.message)}}}function Kn(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hs=1024,zs=30;class Vs{constructor(t){this.container=t,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new Ks(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var t,n;try{const o=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),s=sn();if(((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)==null?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===s||this._heartbeatsCache.heartbeats.some(i=>i.date===s))return;if(this._heartbeatsCache.heartbeats.push({date:s,agent:o}),this._heartbeatsCache.heartbeats.length>zs){const i=Gs(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(i,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){K.warn(r)}}async getHeartbeatsHeader(){var t;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=sn(),{heartbeatsToSend:r,unsentEntries:o}=Ws(this._heartbeatsCache.heartbeats),s=Bn(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,o.length>0?(this._heartbeatsCache.heartbeats=o,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}catch(n){return K.warn(n),""}}}function sn(){return new Date().toISOString().substring(0,10)}function Ws(e,t=Hs){const n=[];let r=e.slice();for(const o of e){const s=n.find(i=>i.agent===o.agent);if(s){if(s.dates.push(o.date),an(n)>t){s.dates.pop();break}}else if(n.push({agent:o.agent,dates:[o.date]}),an(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class Ks{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Un()?Hn().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await Us(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return on(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return on(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...t.heartbeats]})}else return}}function an(e){return Bn(JSON.stringify({version:2,heartbeats:e})).length}function Gs(e){if(e.length===0)return-1;let t=0,n=e[0].date;for(let r=1;r<e.length;r++)e[r].date<n&&(n=e[r].date,t=r);return t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qs(e){ie(new Q("platform-logger",t=>new ss(t),"PRIVATE")),ie(new Q("heartbeat",t=>new Vs(t),"PRIVATE")),se(gt,nn,e),se(gt,nn,"esm2020"),se("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */qs("");const Gn="@firebase/installations",It="0.6.24";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qn=1e4,Jn=`w:${It}`,Yn="FIS_v2",Js="https://firebaseinstallations.googleapis.com/v1",Ys=3600*1e3,Xs="installations",Qs="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zs={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},ae=new Ue(Xs,Qs,Zs);function Xn(e){return e instanceof me&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qn({projectId:e}){return`${Js}/projects/${e}/installations`}function Zn(e){return{token:e.token,requestStatus:2,expiresIn:ti(e.expiresIn),creationTime:Date.now()}}async function er(e,t){const r=(await t.json()).error;return ae.create("request-failed",{requestName:e,serverCode:r.code,serverMessage:r.message,serverStatus:r.status})}function tr({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function ei(e,{refreshToken:t}){const n=tr(e);return n.append("Authorization",ni(t)),n}async function nr(e){const t=await e();return t.status>=500&&t.status<600?e():t}function ti(e){return Number(e.replace("s","000"))}function ni(e){return`${Yn} ${e}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ri({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const r=Qn(e),o=tr(e),s=t.getImmediate({optional:!0});if(s){const c=await s.getHeartbeatsHeader();c&&o.append("x-firebase-client",c)}const i={fid:n,authVersion:Yn,appId:e.appId,sdkVersion:Jn},a={method:"POST",headers:o,body:JSON.stringify(i)},l=await nr(()=>fetch(r,a));if(l.ok){const c=await l.json();return{fid:c.fid||n,registrationStatus:2,refreshToken:c.refreshToken,authToken:Zn(c.authToken)}}else throw await er("Create Installation",l)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rr(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oi(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const si=/^[cdef][\w-]{21}$/,wt="";function ii(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const n=ai(e);return si.test(n)?n:wt}catch{return wt}}function ai(e){return oi(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pe=new Map;function or(e,t){const n=be(e);sr(n,t),di(n,t)}function ci(e,t){ir();const n=be(e);let r=pe.get(n);r||(r=new Set,pe.set(n,r)),r.add(t)}function li(e,t){const n=be(e),r=pe.get(n);r&&(r.delete(t),r.size===0&&pe.delete(n),ar())}function sr(e,t){const n=pe.get(e);if(n)for(const r of n)r(t)}function di(e,t){const n=ir();n&&n.postMessage({key:e,fid:t}),ar()}let oe=null;function ir(){return!oe&&"BroadcastChannel"in self&&(oe=new BroadcastChannel("[Firebase] FID Change"),oe.onmessage=e=>{sr(e.data.key,e.data.fid)}),oe}function ar(){pe.size===0&&oe&&(oe.close(),oe=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ui="firebase-installations-database",fi=1,ce="firebase-installations-store";let rt=null;function kt(){return rt||(rt=ze(ui,fi,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(ce)}}})),rt}async function $e(e,t){const n=be(e),o=(await kt()).transaction(ce,"readwrite"),s=o.objectStore(ce),i=await s.get(n);return await s.put(t,n),await o.done,(!i||i.fid!==t.fid)&&or(e,t.fid),t}async function cr(e){const t=be(e),r=(await kt()).transaction(ce,"readwrite");await r.objectStore(ce).delete(t),await r.done}async function Ve(e,t){const n=be(e),o=(await kt()).transaction(ce,"readwrite"),s=o.objectStore(ce),i=await s.get(n),a=t(i);return a===void 0?await s.delete(n):await s.put(a,n),await o.done,a&&(!i||i.fid!==a.fid)&&or(e,a.fid),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Tt(e){let t;const n=await Ve(e.appConfig,r=>{const o=hi(r),s=pi(e,o);return t=s.registrationPromise,s.installationEntry});return n.fid===wt?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}function hi(e){const t=e||{fid:ii(),registrationStatus:0};return lr(t)}function pi(e,t){if(t.registrationStatus===0){if(!navigator.onLine){const o=Promise.reject(ae.create("app-offline"));return{installationEntry:t,registrationPromise:o}}const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},r=gi(e,n);return{installationEntry:n,registrationPromise:r}}else return t.registrationStatus===1?{installationEntry:t,registrationPromise:mi(e)}:{installationEntry:t}}async function gi(e,t){try{const n=await ri(e,t);return $e(e.appConfig,n)}catch(n){throw Xn(n)&&n.customData.serverCode===409?await cr(e.appConfig):await $e(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}async function mi(e){let t=await cn(e.appConfig);for(;t.registrationStatus===1;)await rr(100),t=await cn(e.appConfig);if(t.registrationStatus===0){const{installationEntry:n,registrationPromise:r}=await Tt(e);return r||n}return t}function cn(e){return Ve(e,t=>{if(!t)throw ae.create("installation-not-found");return lr(t)})}function lr(e){return bi(e)?{fid:e.fid,registrationStatus:0}:e}function bi(e){return e.registrationStatus===1&&e.registrationTime+qn<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function wi({appConfig:e,heartbeatServiceProvider:t},n){const r=yi(e,n),o=ei(e,n),s=t.getImmediate({optional:!0});if(s){const c=await s.getHeartbeatsHeader();c&&o.append("x-firebase-client",c)}const i={installation:{sdkVersion:Jn,appId:e.appId}},a={method:"POST",headers:o,body:JSON.stringify(i)},l=await nr(()=>fetch(r,a));if(l.ok){const c=await l.json();return Zn(c)}else throw await er("Generate Auth Token",l)}function yi(e,{fid:t}){return`${Qn(e)}/${t}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ct(e,t=!1){let n;const r=await Ve(e.appConfig,s=>{if(!dr(s))throw ae.create("not-registered");const i=s.authToken;if(!t&&Ei(i))return s;if(i.requestStatus===1)return n=vi(e,t),s;{if(!navigator.onLine)throw ae.create("app-offline");const a=Ii(s);return n=_i(e,a),a}});return n?await n:r.authToken}async function vi(e,t){let n=await ln(e.appConfig);for(;n.authToken.requestStatus===1;)await rr(100),n=await ln(e.appConfig);const r=n.authToken;return r.requestStatus===0?Ct(e,t):r}function ln(e){return Ve(e,t=>{if(!dr(t))throw ae.create("not-registered");const n=t.authToken;return ki(n)?{...t,authToken:{requestStatus:0}}:t})}async function _i(e,t){try{const n=await wi(e,t),r={...t,authToken:n};return await $e(e.appConfig,r),n}catch(n){if(Xn(n)&&(n.customData.serverCode===401||n.customData.serverCode===404))await cr(e.appConfig);else{const r={...t,authToken:{requestStatus:0}};await $e(e.appConfig,r)}throw n}}function dr(e){return e!==void 0&&e.registrationStatus===2}function Ei(e){return e.requestStatus===2&&!Si(e)}function Si(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+Ys}function Ii(e){const t={requestStatus:1,requestTime:Date.now()};return{...e,authToken:t}}function ki(e){return e.requestStatus===1&&e.requestTime+qn<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ti(e){const t=e,{installationEntry:n,registrationPromise:r}=await Tt(t);return r?r.catch(console.error):Ct(t).catch(console.error),n.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ci(e,t=!1){const n=e;return await Ai(n),(await Ct(n,t)).token}async function Ai(e){const{registrationPromise:t}=await Tt(e);t&&await t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xi(e,t){const{appConfig:n}=e;return ci(n,t),()=>{li(n,t)}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oi(e){if(!e||!e.options)throw ot("App Configuration");if(!e.name)throw ot("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw ot(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function ot(e){return ae.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ur="installations",Ri="installations-internal",Di=e=>{const t=e.getProvider("app").getImmediate(),n=Oi(t),r=St(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:r,_delete:()=>Promise.resolve()}},Ni=e=>{const t=e.getProvider("app").getImmediate(),n=St(t,ur).getImmediate();return{getId:()=>Ti(n),getToken:o=>Ci(n,o)}};function Pi(){ie(new Q(ur,Di,"PUBLIC")),ie(new Q(Ri,Ni,"PRIVATE"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Pi();se(Gn,It);se(Gn,It,"esm2020");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mi="/firebase-messaging-sw.js",Li="/firebase-cloud-messaging-push-scope",fr="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",Fi="https://fcmregistrations.googleapis.com/v1",hr="google.c.a.c_id",$i="google.c.a.c_l",Bi="google.c.a.ts",ji="google.c.a.e",dn=1e4;var un;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(un||(un={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var ge;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked",e.FID_REGISTERED="fid-registered"})(ge||(ge={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function L(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function pr(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),r=atob(n),o=new Uint8Array(r.length);for(let s=0;s<r.length;++s)o[s]=r.charCodeAt(s);return o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const st="fcm_token_details_db",Ui=5,fn="fcm_token_object_Store";async function Hi(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(s=>s.name).includes(st))return null;let t=null;return(await ze(st,Ui,{upgrade:async(r,o,s,i)=>{if(o<2||!r.objectStoreNames.contains(fn))return;const a=i.objectStore(fn),l=await a.index("fcmSenderId").get(e);if(await a.clear(),!!l){if(o===2){const c=l;if(!c.auth||!c.p256dh||!c.endpoint)return;t={token:c.fcmToken,createTime:c.createTime??Date.now(),subscriptionOptions:{auth:c.auth,p256dh:c.p256dh,endpoint:c.endpoint,swScope:c.swScope,vapidKey:typeof c.vapidKey=="string"?c.vapidKey:L(c.vapidKey)}}}else if(o===3){const c=l;t={token:c.fcmToken,createTime:c.createTime,subscriptionOptions:{auth:L(c.auth),p256dh:L(c.p256dh),endpoint:c.endpoint,swScope:c.swScope,vapidKey:L(c.vapidKey)}}}else if(o===4){const c=l;t={token:c.fcmToken,createTime:c.createTime,subscriptionOptions:{auth:L(c.auth),p256dh:L(c.p256dh),endpoint:c.endpoint,swScope:c.swScope,vapidKey:L(c.vapidKey)}}}}}})).close(),await Ne(st),await Ne("fcm_vapid_details_db"),await Ne("undefined"),zi(t)?t:null}function zi(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vi={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","fid-registration-failed":"A problem occurred while creating an FCM registration via FID: {$errorInfo}","fid-unregister-failed":"A problem occurred while unregistering the FCM registration via FID: {$errorInfo}","fid-registration-idb-schema-unavailable":"Unable to read or persist FID registration metadata because the messaging IndexedDB schema is unavailable (for example, the database could not be upgraded to the latest version).","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used.","invalid-on-registered-handler":"No onRegistered callback handler was provided or registered. Implement onRegistered() before register()."},w=new Ue("messaging","Messaging",Vi);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hn="firebase-messaging-database",pn=2,G="firebase-messaging-store",F="firebase-messaging-fid-registration-store",Wi={openDB:ze,deleteDB:Ne};let gn=Wi,Ee=null;function Ki(e,t,n){switch(t){case 0:if(e.createObjectStore(G),n===1)break;case 1:n===2&&e.createObjectStore(F)}}function mn(e){return{upgrade:(t,n)=>{Ki(t,n,e)},blocked:()=>{},blocking:(t,n,r)=>{var o;Ee=null,(o=r.target)==null||o.close()},terminated:()=>{Ee=null}}}function we(){return Ee||(Ee=gn.openDB(hn,pn,mn(2)).catch(()=>gn.openDB(hn,pn-1,mn(1)))),Ee}function gr(e,t){return e.objectStoreNames.contains(t)}function At(e){if(!gr(e,F))throw w.create("fid-registration-idb-schema-unavailable")}async function mr(e){const t=ye(e),r=await(await we()).transaction(G).objectStore(G).get(t);if(r)return r;{const o=await Hi(e.appConfig.senderId);if(o)return await xt(e,o),o}}async function xt(e,t){const n=ye(e),r=await we(),o=[G],s=gr(r,F);s&&o.push(F);const i=r.transaction(o,"readwrite");return await i.objectStore(G).put(t,n),s&&await i.objectStore(F).delete(n),await i.done,t}async function Gi(e){const t=ye(e),r=(await we()).transaction(G,"readwrite");await r.objectStore(G).delete(t),await r.done}async function Ot(e){const t=ye(e),n=await we();return At(n),await n.transaction(F).objectStore(F).get(t)}async function qi(e,t){const n=ye(e),r=await we();At(r);const o=r.transaction([G,F],"readwrite");return await o.objectStore(F).put(t,n),await o.objectStore(G).delete(n),await o.done,t}async function Ji(e){const t=ye(e),n=await we();At(n);const r=n.transaction(F,"readwrite");await r.objectStore(F).delete(t),await r.done}function ye({appConfig:e}){return e.appId}const bn="@firebase/messaging",yt="0.13.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yi=3,Xi=1e3;async function Qi(e,t){const n=await Te(e),r=Rt(t,e.appConfig.appName,!1),o={method:"POST",headers:n,body:JSON.stringify(r)};let s;try{s=await(await fetch(ke(e.appConfig),o)).json()}catch(i){throw w.create("token-subscribe-failed",{errorInfo:i==null?void 0:i.toString()})}if(s.error){const i=s.error.message;throw w.create("token-subscribe-failed",{errorInfo:i})}if(!s.token)throw w.create("token-subscribe-no-token");return s.token}async function Zi(e,t){var l;const n=await Te(e),r=Rt(t,e.appConfig.appName,!0),o={method:"POST",headers:n,body:JSON.stringify(r)};let s;try{s=await oa(()=>fetch(ke(e.appConfig),o),Yi,Xi)}catch(c){throw w.create("fid-registration-failed",{errorInfo:c==null?void 0:c.toString()})}if(s.ok)return{responseFid:await ta(s)};let i;try{i=await s.json()}catch{throw w.create("fid-registration-failed",{errorInfo:s.statusText})}const a=((l=i.error)==null?void 0:l.message)??s.statusText;throw w.create("fid-registration-failed",{errorInfo:a})}async function ea(e,t){var s;const r={method:"DELETE",headers:await Te(e)};let o;try{o=await fetch(`${ke(e.appConfig)}/${t}`,r)}catch(i){throw w.create("fid-unregister-failed",{errorInfo:i==null?void 0:i.toString()})}if(!o.ok)try{throw((s=(await o.json()).error)==null?void 0:s.message)??o.statusText}catch(i){throw w.create("fid-unregister-failed",{errorInfo:typeof i=="string"&&i||o.statusText||(i==null?void 0:i.toString())})}}async function ta(e){const t=await e.text();if(!t.trim())throw w.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is empty"});let n;try{n=JSON.parse(t)}catch{throw w.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response body is not valid JSON"})}const r=n.name;if(typeof r!="string"||r.length===0)throw w.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response did not include a non-empty name"});return na(r)}const wn="/registrations/";function na(e){const t=e.indexOf(wn);if(t!==-1){const n=e.slice(t+wn.length);if(n.length>0)return n}throw w.create("fid-registration-failed",{errorInfo:"CreateRegistration succeeded but response name is not a valid registration resource name"})}async function ra(e,t){const n=await Te(e),r=Rt(t.subscriptionOptions,e.appConfig.appName,!1),o={method:"PATCH",headers:n,body:JSON.stringify(r)};let s;try{s=await(await fetch(`${ke(e.appConfig)}/${t.token}`,o)).json()}catch(i){throw w.create("token-update-failed",{errorInfo:i==null?void 0:i.toString()})}if(s.error){const i=s.error.message;throw w.create("token-update-failed",{errorInfo:i})}if(!s.token)throw w.create("token-update-no-token");return s.token}async function br(e,t){const r={method:"DELETE",headers:await Te(e)};try{const s=await(await fetch(`${ke(e.appConfig)}/${t}`,r)).json();if(s.error){const i=s.error.message;throw w.create("token-unsubscribe-failed",{errorInfo:i})}}catch(o){throw w.create("token-unsubscribe-failed",{errorInfo:o==null?void 0:o.toString()})}}async function oa(e,t,n){let r;for(let o=0;o<t;o++)try{return await e()}catch(s){if(r=s,o<t-1){const i=n*Math.pow(2,o);await new Promise(a=>setTimeout(a,i))}}throw r}function ke({projectId:e}){return`${Fi}/projects/${e}/registrations`}async function Te({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function sa(e,t){var n,r;try{if(/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(e))return new URL(e).host}catch{}try{if(typeof self<"u"&&((n=self.location)!=null&&n.href))return new URL(e,self.location.origin).host}catch{}return typeof self<"u"&&((r=self.location)!=null&&r.host)?self.location.host:t}function Rt({p256dh:e,auth:t,endpoint:n,vapidKey:r,swScope:o},s,i){const a={web:{origin:sa(o,s),endpoint:n,auth:t,p256dh:e}};return i&&(a.fcm_sdk_version=yt),r!==fr&&(a.web.applicationPubKey=r),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ia=10080*60*1e3;async function aa(e){const t=await fa(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:L(t.getKey("auth")),p256dh:L(t.getKey("p256dh"))},r=await mr(e.firebaseDependencies);if(r){if(ha(r.subscriptionOptions,n))return Date.now()>=r.createTime+ia?ua(e,{token:r.token,createTime:Date.now(),subscriptionOptions:n}):r.token;try{await br(e.firebaseDependencies,r.token)}catch(o){console.warn(o)}return yn(e.firebaseDependencies,n)}else return yn(e.firebaseDependencies,n)}async function ca(e,t){await br(e.firebaseDependencies,t.token),await Gi(e.firebaseDependencies),await wr(e.firebaseDependencies)}async function la(e){const t=await Ot(e.firebaseDependencies).catch(()=>{}),n=t==null?void 0:t.fid;n&&await ea(e.firebaseDependencies,n),await wr(e.firebaseDependencies),n&&ga(e,n)}async function da(e){const t=await mr(e.firebaseDependencies);t?await ca(e,t):await la(e);const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function ua(e,t){try{const n=await ra(e.firebaseDependencies,t),r={...t,token:n,createTime:Date.now()};return await xt(e.firebaseDependencies,r),n}catch(n){throw n}}async function yn(e,t){const r={token:await Qi(e,t),createTime:Date.now(),subscriptionOptions:t};return await xt(e,r),r.token}async function fa(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:pr(t)})}function ha(e,t){const n=t.vapidKey===e.vapidKey,r=t.endpoint===e.endpoint,o=t.auth===e.auth,s=t.p256dh===e.p256dh;return n&&r&&o&&s}async function wr(e){try{await Ji(e)}catch{}}function pa(e,t){const n=e.onRegisteredHandler;n&&(typeof n=="function"?n(t):n.next(t))}function ga(e,t){const n=e.onUnregisteredHandler;n&&(typeof n=="function"?n(t):n.next(t))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yr(e){try{e.swRegistration=await navigator.serviceWorker.register(Mi,{scope:Li}),e.swRegistration.update().catch(()=>{}),await ma(e.swRegistration)}catch(t){throw w.create("failed-service-worker-registration",{browserErrorMessage:t==null?void 0:t.message})}}async function ma(e){return new Promise((t,n)=>{const r=setTimeout(()=>n(new Error(`Service worker not registered after ${dn} ms`)),dn),o=e.installing||e.waiting;e.active?(clearTimeout(r),t()):o?o.onstatechange=s=>{var i;((i=s.target)==null?void 0:i.state)==="activated"&&(o.onstatechange=null,clearTimeout(r),t())}:(clearTimeout(r),n(new Error("No incoming service worker found.")))})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function vr(e,t){if(!t&&!e.swRegistration&&await yr(e),!(!t&&e.swRegistration)){if(!(t instanceof ServiceWorkerRegistration))throw w.create("invalid-sw-registration");e.swRegistration=t}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _r(e,t){t?e.vapidKey=t:e.vapidKey||(e.vapidKey=fr)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vn=3;async function ba(e,t){const n=await wa(e.swRegistration,e.vapidKey),r={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:n.endpoint,auth:L(n.getKey("auth")),p256dh:L(n.getKey("p256dh"))},o=e.firebaseDependencies.installations;for(let s=0;s<vn;s++){const{responseFid:i}=await Zi(e.firebaseDependencies,r);if(i===t)return;s<vn-1&&await o.getToken(!0)}throw w.create("fid-registration-failed",{errorInfo:"CreateRegistration response FID does not match Firebase Installation ID"})}async function wa(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:pr(t)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ya=10080*60*1e3;async function Er(e,t){if(!navigator)throw w.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw w.create("permission-blocked");if(!e.onRegisteredHandler)throw w.create("invalid-on-registered-handler");await _r(e,t==null?void 0:t.vapidKey),await vr(e,t==null?void 0:t.serviceWorkerRegistration);const n=e._registerNotifyChain.catch(()=>{});return e._registerNotifyChain=n.then(async()=>{const r=await e.firebaseDependencies.installations.getId(),o=await Ot(e.firebaseDependencies),s=Date.now();if((!o||o.fid!==r||s>=o.lastRegisterTime+ya)&&(await ba(e,r),await qi(e.firebaseDependencies,{fid:r,lastRegisterTime:s,vapidKey:e.vapidKey})),!e.onRegisteredHandler)throw w.create("invalid-on-registered-handler");pa(e,r)}),e._registerNotifyChain}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function va(e,t){return xi(t,()=>{(async()=>!e.onRegisteredHandler||!await Ot(e.firebaseDependencies)||await Er(e).catch(()=>{}))()})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _n(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return _a(t,e),Ea(t,e),Sa(t,e),t}function _a(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const r=t.notification.body;r&&(e.notification.body=r);const o=t.notification.image;o&&(e.notification.image=o);const s=t.notification.icon;s&&(e.notification.icon=s)}function Ea(e,t){t.data&&(e.data=t.data)}function Sa(e,t){var o,s,i,a;if(!t.fcmOptions&&!((o=t.notification)!=null&&o.click_action))return;e.fcmOptions={};const n=((s=t.fcmOptions)==null?void 0:s.link)??((i=t.notification)==null?void 0:i.click_action);n&&(e.fcmOptions.link=n);const r=(a=t.fcmOptions)==null?void 0:a.analytics_label;r&&(e.fcmOptions.analyticsLabel=r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ia(e){return typeof e=="object"&&!!e&&hr in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ka(e){if(!e||!e.options)throw it("App Configuration Object");if(!e.name)throw it("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const r of t)if(!n[r])throw it(r);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function it(e){return w.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ta{constructor(t,n,r){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.onRegisteredHandler=null,this.onUnregisteredHandler=null,this._registerNotifyChain=Promise.resolve(),this._fidChangeUnsubscribe=null,this.logEvents=[],this.logQueue={state:"stopped"};const o=ka(t);this.firebaseDependencies={app:t,appConfig:o,installations:n,analyticsProvider:r}}_delete(){return this._fidChangeUnsubscribe&&(this._fidChangeUnsubscribe(),this._fidChangeUnsubscribe=null),this.logQueue.state==="scheduled"&&clearTimeout(this.logQueue.timerId),this.logQueue={state:"stopped"},Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Sr(e,t){if(!navigator)throw w.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw w.create("permission-blocked");return await _r(e,t==null?void 0:t.vapidKey),await vr(e,t==null?void 0:t.serviceWorkerRegistration),aa(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ca(e,t,n){const r=Aa(t);(await e.firebaseDependencies.analyticsProvider.get()).logEvent(r,{message_id:n[hr],message_name:n[$i],message_time:n[Bi],message_device_time:Math.floor(Date.now()/1e3)})}function Aa(e){switch(e){case ge.NOTIFICATION_CLICKED:return"notification_open";case ge.PUSH_RECEIVED:return"notification_foreground";default:throw new Error}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xa(e,t){const n=t.data;if(!n.isFirebaseMessaging)return;if(e.onMessageHandler&&n.messageType===ge.PUSH_RECEIVED&&(typeof e.onMessageHandler=="function"?e.onMessageHandler(_n(n)):e.onMessageHandler.next(_n(n))),e.onRegisteredHandler&&n.messageType===ge.FID_REGISTERED){const o=n.fid;typeof e.onRegisteredHandler=="function"?e.onRegisteredHandler(o):e.onRegisteredHandler.next(o)}const r=n.data;Ia(r)&&r[ji]==="1"&&await Ca(e,n.messageType,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oa=e=>{const t=new Ta(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return navigator.serviceWorker.addEventListener("message",n=>xa(t,n)),t._fidChangeUnsubscribe=va(t,e.getProvider("installations").getImmediate()),t},Ra=e=>{const t=e.getProvider("messaging").getImmediate();return{getToken:r=>Sr(t,r),register:r=>Er(t,r)}};function Da(){ie(new Q("messaging",Oa,"PUBLIC")),ie(new Q("messaging-internal",Ra,"PRIVATE")),se(bn,yt),se(bn,yt,"esm2020")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _e(){try{await Hn()}catch{return!1}return typeof window<"u"&&Un()&&Fo()&&"serviceWorker"in navigator&&"PushManager"in window&&"Notification"in window&&"fetch"in window&&ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification")&&PushSubscription.prototype.hasOwnProperty("getKey")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Na(e){if(!navigator)throw w.create("only-available-in-window");return e.swRegistration||await yr(e),da(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pa(e,t){if(!navigator)throw w.create("only-available-in-window");return e.onMessageHandler=t,()=>{e.onMessageHandler=null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(e=$s()){return _e().then(t=>{if(!t)throw w.create("unsupported-browser")},t=>{throw w.create("indexed-db-unsupported")}),St(He(e),"messaging").getImmediate()}async function Ma(e,t){return e=He(e),Sr(e,t)}function La(e){return e=He(e),Na(e)}function Fa(e,t){return e=He(e),Pa(e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Da();class We extends ee{constructor(){super(),_e().then(t=>{if(!t)return;const n=at();Fa(n,r=>this.handleNotificationReceived(r))})}async checkPermissions(){return await _e()?{receive:this.convertNotificationPermissionToPermissionState(Notification.permission)}:{receive:"denied"}}async requestPermissions(){if(!await _e())return{receive:"denied"};const n=await Notification.requestPermission();return{receive:this.convertNotificationPermissionToPermissionState(n)}}async isSupported(){return{isSupported:await _e()}}async getToken(t){const n=at();return{token:await Ma(n,{vapidKey:t.vapidKey,serviceWorkerRegistration:t.serviceWorkerRegistration})}}async deleteToken(){const t=at();await La(t)}async getDeliveredNotifications(){this.throwUnimplementedError()}async removeDeliveredNotifications(t){this.throwUnimplementedError()}async removeAllDeliveredNotifications(){this.throwUnimplementedError()}async subscribeToTopic(t){this.throwUnimplementedError()}async unsubscribeFromTopic(t){this.throwUnimplementedError()}async createChannel(t){this.throwUnimplementedError()}async deleteChannel(t){this.throwUnimplementedError()}async listChannels(){this.throwUnimplementedError()}handleNotificationReceived(t){const r={notification:this.createNotificationResult(t)};this.notifyListeners(We.notificationReceivedEvent,r)}createNotificationResult(t){var n,r,o;return{body:(n=t.notification)===null||n===void 0?void 0:n.body,data:t.data,id:t.messageId,image:(r=t.notification)===null||r===void 0?void 0:r.image,title:(o=t.notification)===null||o===void 0?void 0:o.title}}convertNotificationPermissionToPermissionState(t){let n="prompt";switch(t){case"granted":n="granted";break;case"denied":n="denied";break}return n}throwUnimplementedError(){throw this.unimplemented("Not implemented on web.")}}We.notificationReceivedEvent="notificationReceived";const $a=Object.freeze(Object.defineProperty({__proto__:null,FirebaseMessagingWeb:We},Symbol.toStringTag,{value:"Module"}));var ue;(function(e){e.Heavy="HEAVY",e.Medium="MEDIUM",e.Light="LIGHT"})(ue||(ue={}));var fe;(function(e){e.Success="SUCCESS",e.Warning="WARNING",e.Error="ERROR"})(fe||(fe={}));const Ba=q("Haptics",{web:()=>Ie(()=>Promise.resolve().then(()=>qa),void 0).then(e=>new e.HapticsWeb)}),oc=Object.freeze(Object.defineProperty({__proto__:null,Haptics:Ba,get ImpactStyle(){return ue},get NotificationType(){return fe}},Symbol.toStringTag,{value:"Module"})),ja=q("App",{web:()=>Ie(()=>Promise.resolve().then(()=>Ya),void 0).then(e=>new e.AppWeb)}),sc=Object.freeze(Object.defineProperty({__proto__:null,App:ja},Symbol.toStringTag,{value:"Module"}));var Be;(function(e){e.Dark="DARK",e.Light="LIGHT",e.Default="DEFAULT"})(Be||(Be={}));var je;(function(e){e.None="NONE",e.Slide="SLIDE",e.Fade="FADE"})(je||(je={}));const Ua=je,Ha=Be,za=q("StatusBar"),ic=Object.freeze(Object.defineProperty({__proto__:null,get Animation(){return je},StatusBar:za,StatusBarAnimation:Ua,StatusBarStyle:Ha,get Style(){return Be}},Symbol.toStringTag,{value:"Module"})),Va=q("SplashScreen",{web:()=>Ie(()=>Promise.resolve().then(()=>Qa),void 0).then(e=>new e.SplashScreenWeb)}),ac=Object.freeze(Object.defineProperty({__proto__:null,SplashScreen:Va},Symbol.toStringTag,{value:"Module"}));class Wa extends ee{constructor(){super(),this.credentialStore=new Map}isAvailable(){return Promise.resolve({isAvailable:!0,authenticationStrength:Le.STRONG,biometryType:Me.TOUCH_ID,deviceIsSecure:!0,strongBiometryIsAvailable:!0})}async addListener(t,n){return{remove:async()=>{}}}verifyIdentity(t){return console.log("verifyIdentity (dummy implementation)"),Promise.resolve()}getCredentials(t){console.log("getCredentials (dummy implementation)",{server:t.server});const n=this.credentialStore.get(t.server);if(!n)throw new Error("No credentials found for the specified server");return Promise.resolve(n)}getSecureCredentials(t){console.log("getSecureCredentials (dummy implementation)",{server:t.server});const n=this.credentialStore.get(t.server);if(!n)throw new Error("No credentials found for the specified server");return Promise.resolve(n)}setCredentials(t){return console.log("setCredentials (dummy implementation)",{server:t.server}),this.credentialStore.set(t.server,{username:t.username,password:t.password}),Promise.resolve()}deleteCredentials(t){return console.log("deleteCredentials (dummy implementation)",{server:t.server}),this.credentialStore.delete(t.server),Promise.resolve()}isCredentialsSaved(t){return console.log("isCredentialsSaved (dummy implementation)",{server:t.server}),Promise.resolve({isSaved:this.credentialStore.has(t.server)})}async getPluginVersion(){return{version:"web"}}}const Ka=Object.freeze(Object.defineProperty({__proto__:null,NativeBiometricWeb:Wa},Symbol.toStringTag,{value:"Module"}));class Ga extends ee{constructor(){super(...arguments),this.selectionStarted=!1}async impact(t){const n=this.patternForImpact(t==null?void 0:t.style);this.vibrateWithPattern(n)}async notification(t){const n=this.patternForNotification(t==null?void 0:t.type);this.vibrateWithPattern(n)}async vibrate(t){const n=(t==null?void 0:t.duration)||300;this.vibrateWithPattern([n])}async selectionStart(){this.selectionStarted=!0}async selectionChanged(){this.selectionStarted&&this.vibrateWithPattern([70])}async selectionEnd(){this.selectionStarted=!1}patternForImpact(t=ue.Heavy){return t===ue.Medium?[43]:t===ue.Light?[20]:[61]}patternForNotification(t=fe.Success){return t===fe.Warning?[30,40,30,50,60]:t===fe.Error?[27,45,50]:[35,65,21]}vibrateWithPattern(t){if(navigator.vibrate)navigator.vibrate(t);else throw this.unavailable("Browser does not support the vibrate API")}}const qa=Object.freeze(Object.defineProperty({__proto__:null,HapticsWeb:Ga},Symbol.toStringTag,{value:"Module"}));class Ja extends ee{constructor(){super(),this.handleVisibilityChange=()=>{const t={isActive:document.hidden!==!0};this.notifyListeners("appStateChange",t),document.hidden?this.notifyListeners("pause",null):this.notifyListeners("resume",null)},document.addEventListener("visibilitychange",this.handleVisibilityChange,!1)}exitApp(){throw this.unimplemented("Not implemented on web.")}async getInfo(){throw this.unimplemented("Not implemented on web.")}async getLaunchUrl(){return{url:""}}async getState(){return{isActive:document.hidden!==!0}}async minimizeApp(){throw this.unimplemented("Not implemented on web.")}async toggleBackButtonHandler(){throw this.unimplemented("Not implemented on web.")}async getAppLanguage(){return{value:navigator.language.split("-")[0].toLowerCase()}}}const Ya=Object.freeze(Object.defineProperty({__proto__:null,AppWeb:Ja},Symbol.toStringTag,{value:"Module"}));class Xa extends ee{async show(t){}async hide(t){}}const Qa=Object.freeze(Object.defineProperty({__proto__:null,SplashScreenWeb:Xa},Symbol.toStringTag,{value:"Module"}));export{lt as C,tc as F,qt as I,Ie as _,q as a,oc as b,Za as c,sc as d,ic as e,ac as f,rc as i,nc as r,ec as t};
